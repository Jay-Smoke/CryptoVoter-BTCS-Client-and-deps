cd /opt/cryptoVoter-btcs/
./cryptoVoter-btcs
cd -
